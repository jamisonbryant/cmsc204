package edu.montgomerycollege.cmsc204.jmeyers;

/**
 * Requires a definition of the key for a particular object
 * The key is a string.
 * @author JMYERS
 *
 */
public interface Keyable {
	public String getKey();

}
